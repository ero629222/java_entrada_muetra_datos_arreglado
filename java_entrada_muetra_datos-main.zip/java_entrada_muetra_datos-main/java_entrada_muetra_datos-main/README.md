# java_entrada_muetra_datos
Comisión_1112_actividadPráctica_unidad_2

Ejercicio:
 Crear un programa en java en el cual se pida al usuario ingresar su nombre, apellido, edad, hobbie, editor de código preferido, sistema operativo que utiliza, luego deberá mostrarse por consola los datos ingresad
 
 
 
 
 

